﻿using Employe.Data.Repository;
using EmployeeApp.Core.Models;


namespace Employe.Data.Repositories
{
    public class EmployeRepository: Repository<Employe>
    {

    }
}
